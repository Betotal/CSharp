﻿namespace CursoFoop_Solid_Exercicio_5
{
    class Pizza
    {
    }
}
