﻿using System;

namespace CursoFoop_Solid_Exercicio_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
