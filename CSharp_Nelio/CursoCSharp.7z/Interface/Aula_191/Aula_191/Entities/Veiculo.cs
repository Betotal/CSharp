﻿
namespace Aula_191.Entities {
    class Veiculo {

        public string Modelo { get; set; }

        public Veiculo(string modelo) {
            Modelo = modelo;
        }
    }
}
