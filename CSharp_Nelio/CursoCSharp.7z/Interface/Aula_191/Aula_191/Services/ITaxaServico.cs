﻿
namespace Aula_191.Services{
    interface ITaxaServico{
        double Taxa(double quantia);
    }
}
