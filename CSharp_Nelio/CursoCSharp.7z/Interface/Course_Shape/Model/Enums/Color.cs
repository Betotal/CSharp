﻿namespace Course.Model.Enums {
    enum Color {

        Black, White
    }
}
