﻿namespace Course.Devices {
    interface IScanner {
        string Scan();
    }
}
