﻿using System;

namespace Exerc_Encapsu1 {
    class Program {
        static void Main(string[] args) {


            Console.WriteLine("Hello World!");
        }
    }
}
