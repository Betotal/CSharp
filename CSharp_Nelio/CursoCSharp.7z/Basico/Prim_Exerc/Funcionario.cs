﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prim_Exerc {
    class Funcionario {
        public string Nome;
        public double Salario;
    }
}
