﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prim_Exerc {
    class Pessoa {
        public string Nome;
        public int Idade;
        
    }
}
