﻿
namespace Tabuleiro_Pasta {
    enum Cor {
        Branco,
        Preto,
        Vermelho,
        Amarelo,
        Ciano,
        Verde,
        Laranja,
        Roxo
    };
}
