﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tabuleiro_Pasta {
    class TabuleiroException : Exception {
        public TabuleiroException(string msg) : base(msg) {

        }
    }
}
