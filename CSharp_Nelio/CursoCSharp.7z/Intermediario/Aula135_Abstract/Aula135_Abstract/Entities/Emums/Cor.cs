﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula135_Abstract.Entities.Emums
{
    enum Cor
    {
        Preto,
        Azul,
        Vermelho,
        Amarelo,
        Roxo,
        Verde,
        Laranja,
        Branco
    };
}
