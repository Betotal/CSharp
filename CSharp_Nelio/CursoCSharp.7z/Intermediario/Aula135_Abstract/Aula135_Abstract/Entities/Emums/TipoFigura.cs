﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula135_Abstract.Entities.Emums
{
    enum TipoFigura
    {
        Circulo,
        Triangulo,
        Retangulo,
        Quadrado
    };
}
