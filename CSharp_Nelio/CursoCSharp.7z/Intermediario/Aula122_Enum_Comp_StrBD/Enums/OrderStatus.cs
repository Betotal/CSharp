﻿namespace Aula122_Enum_Comp_StrBD.Enums
{
    enum OrderStatus
    {
        Pgto_Pendente,
        Processando,
        Enviado,
        Entregue
    };
}
