﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aula132_Fixacao.Emums
{
    enum TipoProduto
    {
        Comum,
        Usado,
        Importado
    };
}
