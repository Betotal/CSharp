﻿namespace Aula118_120_Composition.Entities.Enums
{
    enum WorkerLevel
    {
        Junior,
        Pleno,
        Senior
    };
}
