﻿namespace Aula118_120_Composition.Entities
{
    class Departamento
    {
        public string Name { get; set; }

        public Departamento()
        {
        }
        public Departamento(string name)
        {
            Name = name;
        }

    }
}
