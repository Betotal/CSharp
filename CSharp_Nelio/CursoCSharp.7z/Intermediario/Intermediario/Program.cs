﻿using System;

namespace Intermediario {
    internal class Program {
        static void Main(string[] args) {
            Console.WriteLine("Hello World!");
        }
    }
}
